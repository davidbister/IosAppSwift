//
//  LoginViewController.swift
//  TV Shows
//
//  Created by Infinum on 12.07.2021..
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        loginButton.setTitle("Login", for: .normal)
        loginButton.layer.cornerRadius=10
        // Do any additional setup after loading the view.
        

        activityIndicator.hidesWhenStopped=true
    }
    var counter:Int=0
    func increaseCounter(){
        
        
        counter+=1
        messageLabel.text="\(counter)"
    }
    
    // MARK: - AcitonHandlers
 
    @IBAction func loginAction(_ sender: UIButton) {
        
       increaseCounter()
    }
    
   
    
    @IBAction func activateIndicatorPressed(_ sender: UIButton) {
        
        if activityIndicator.isAnimating {
            
            activityIndicator.stopAnimating()
        } else  {
            activityIndicator.startAnimating()
            
        }
        
//          sender.isEnabled = false
//          DispatchQueue.main.asyncAfter(deadline: .now() + 0.01) {
//
//            sleep(3)
//            self.activityIndicator.stopAnimating()
//            sender.isEnabled = true
          
    }
    

}
